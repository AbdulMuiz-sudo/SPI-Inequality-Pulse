# Power BI model inventory

This inventory was read from `SPI_dashboard.SemanticModel/definition` after the edits in this project. It describes fields declared by the model; it does not verify current row values in Databricks.

## Tables and columns

- `dim_city`: `city_key`, `city`, `city_code`, `load_timestamp`
- `dim_commodity`: `commodity_key`, `commodity_name`, `unit`, `category`, `load_timestamp`, `Is Staple` (calculated)
- `dim_date`: `date_key`, `full_date`, `year`, `quarter`, `month`, `month_name`, `year_month`, `week_of_year`, `day_name`, `load_timestamp`
- `dim_item`: `item_key`, `item_name`, `unit`, `item_group`, `load_timestamp`, `Is Petrol Diesel` (calculated)
- `dim_market`: `market_key`, `country`, `admin_region`, `market`, `load_timestamp`
- `dim_quintile`: `quintile_key`, `quintile`, `income_band`, `income_rank`, `weight_group`, `load_timestamp`
- `fact_city_price_weekly`: `date_key`, `item_key`, `city_key`, `min_price`, `avg_price`, `max_price`, `price_dispersion_pct`, `avg_price_wow_pct`, `load_timestamp`
- `fact_item_weekly`: `date_key`, `item_key`, `price_direction`, `price_current`, `price_prev_week`, `price_prev_year`, `pct_change_wow`, `pct_change_yoy`, `weight_lowest`, `weight_combined`, `impact_lowest`, `impact_combined`, `load_timestamp`
- `fact_quintile_weekly`: `date_key`, `quintile_key`, `index_value`, `index_prev_week`, `index_prev_year`, `pct_change_wow`, `pct_change_yoy`, `index_vs_combined`, `load_timestamp`
- `fact_wfp_price_monthly`: `date_key`, `market_key`, `commodity_key`, `price_type`, `price`, `currency`, `pct_change_mom`, `is_revised_flag`, `load_timestamp`
- `pipeline_execution_logs`: `log_id`, `batch_id`, `load_type`, `layer`, `file_processed`, `target_table`, `start_time`, `end_time`, `status`, `rows_read`, `rows_inserted`, `rows_updated`, `rows_quarantined`, `error_message`, `message`, `Run Date` (calculated), `Duration (sec)` (calculated)
- `quarantine_records`: `quarantine_id`, `batch_id`, `layer`, `source_file`, `record_ref`, `reason`, `record_json`, `quarantined_at`
- `Lag` (new, disconnected): `Value`, generated 0–4
- `Subsidy Cut` (existing parameter): `Subsidy Cut`, generated 0–100 by 1; measure `Subsidy Cut Value`
- `_Measures (2)` (existing measure table; retained so current visual bindings remain valid): no data columns

Power BI's automatic `LocalDateTable_*` and `DateTableTemplate_*` objects are also in the model. They are generated date metadata, not business tables.

## Measures

The model had 15 measures in `_Measures (2)` before this edit; those were kept. Their definitions had stray Markdown fences removed where present. The parameter table already had `[Subsidy Cut Value]`.

**Existing measures:** `[Index]`, `[Latest Week]`, `[Q1 Index]`, `[Q5 Index]`, `[Index Latest Week]`, `[Worst Hit Quintile]`, `[Is Worst]`, `[Gap]`, `[Gap Latest]`, `[Gap 4w Earlier]`, `[Gap 12w Earlier]`, `[Gap Change 4w]`, `[Gap Change 12w]`, `[Gap Trend 4w]`, `[Gap Trend 12w]`.

**Added for WFP volatility:** `[Staple Volatility]`, `[Volatility 12M]`, `[Volatility Rank]`, `[Pakistan Rank]`.

**Added for fuel pass-through:** `[Fuel WoW]`, `[Food WoW]`, `[Lag Correlation]`, `[Best Lag]`, `[Is Best Lag]`, `[Fuel WoW Spike]`, `[Top 5 Fuel Spike]`.

**Added for the subsidy scenario:** `[Q1 Index Latest]`, `[Weight Lowest Latest]`, `[Simulated Q1 Drop]`, `[Simulated Q1 Index]`, `[Relief per 1pct Cut]`, `[Top 10 Simulated Q1 Drop]`.

**Added for pipeline health:** `[Pipeline Run Count]`, `[Inserted Rows]`, `[Updated Rows]`, `[Average Run Duration (sec)]`, `[Quarantine Count]`.

**Added for optional analysis:** `[Combined Impact]`, `[Item Price Volatility]`, `[Top 10 Item Price Volatility]`, `[Average City Price Dispersion]`.

There are now 41 measures in `_Measures (2)` plus the existing `[Subsidy Cut Value]` measure, 42 total. The new `Lag` table and all visual field bindings were checked against the model field names.

## Report pages

1. **Who's Hurting Most?** Repaired existing line/bar visuals; added date range slicer and the two missing gap cards. Replaced two KPI visual types that had no trend-axis bindings with standard cards.
2. **Regional Volatility Benchmark.** Left empty at your direction because only Pakistan WFP data is loaded; a country-to-country comparison would not be supported by the current rows.
3. **Fuel Impact & Pass-Through.** Added lag slicer, lag correlation chart, best-lag card, dual-axis fuel/food line chart, and top-five spike table.
4. **What Would Actually Help?** Moved the existing subsidy slider here and set its saved value to 10; added item selection, top-ten drop chart, three cards, and ranked relief table.
5. **Pipeline Health.** Added run status, rows over time, duration, failure details, quarantine breakdown, and quarantine count visuals.
6. **Optional Analysis.** Added basket composition, item volatility, and city comparison visuals from the optional section of the supplied instructions.

Page 2 remains blank by design until WFP data for the other requested countries is loaded.
